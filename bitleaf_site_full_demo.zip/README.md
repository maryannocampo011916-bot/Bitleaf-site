# BitLeaf Demo (Full)
This package includes a full single-file demo site (index.html), a logo (logo.png), and deployment instructions.

## Deploy
- GitHub Pages: create a repo, upload files, enable Pages on main branch root.
- Netlify: drag & drop folder with index.html + logo.png.
